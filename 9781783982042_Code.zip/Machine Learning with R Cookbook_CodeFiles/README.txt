All the chapters have executable R code. 
